import Link from 'next/link'
import { Metadata } from 'next'
import { getFeaturedTools, getAllCategories, getAllComparisons } from '@/lib/data'
import { breadcrumbSchema } from '@/lib/schema'
import { JsonLd } from '@/components/JsonLd'

export const metadata: Metadata = {
  title: 'AI工具导航 — 发现最好用的AI工具',
  description: '精选最实用的AI工具，涵盖写作、绘图、编程、视频等分类，帮助你找到最适合的AI助手。',
}

export default async function HomePage() {
  const [featuredTools, categories, comparisons] = await Promise.all([
    getFeaturedTools(),
    getAllCategories(),
    getAllComparisons(),
  ])

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://ai-tools-nav.com'

  const breadcrumbs = [{ name: '首页', url: siteUrl }]

  const pricingLabel: Record<string, string> = {
    free: '免费',
    freemium: '免费+付费',
    paid: '付费',
    enterprise: '企业版',
  }

  return (
    <>
      <JsonLd data={breadcrumbSchema(breadcrumbs)} />

      <main>
        {/* Hero */}
        <section className="bg-gradient-to-br from-brand-600 to-brand-800 text-white py-16">
          <div className="container-content text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-4">发现最好用的AI工具</h1>
            <p className="text-xl text-brand-100 mb-8 max-w-2xl mx-auto">
              精选 {featuredTools.length}+ 款AI工具，覆盖写作、绘图、编程、视频等场景，助你提升效率
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <Link href="/category" className="bg-white text-brand-700 font-semibold px-6 py-3 rounded-lg hover:bg-brand-50 transition-colors">
                浏览分类
              </Link>
              <Link href="/compare" className="border border-white text-white font-semibold px-6 py-3 rounded-lg hover:bg-white/10 transition-colors">
                工具对比
              </Link>
            </div>
          </div>
        </section>

        {/* Categories */}
        <section className="container-content py-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">按分类浏览</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((cat) => (
              <Link
                key={cat.slug}
                href={`/category/${cat.slug}`}
                className="card text-center hover:shadow-md transition-shadow group"
              >
                {cat.icon && <div className="text-3xl mb-2">{cat.icon}</div>}
                <div className="font-medium text-gray-900 group-hover:text-brand-600 transition-colors text-sm">
                  {cat.name}
                </div>
                <div className="text-xs text-gray-400 mt-1">{cat.toolCount} 款工具</div>
              </Link>
            ))}
          </div>
        </section>

        {/* Featured tools */}
        <section className="bg-gray-50 py-12">
          <div className="container-content">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">精选AI工具</h2>
              <Link href="/tools" className="text-brand-600 hover:underline text-sm font-medium">
                查看全部 →
              </Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredTools.map((tool) => (
                <Link
                  key={tool.slug}
                  href={`/tools/${tool.slug}`}
                  className="card bg-white hover:shadow-md transition-shadow group"
                >
                  <div className="flex items-center gap-3 mb-3">
                    {tool.logoUrl && (
                      <img
                        src={tool.logoUrl}
                        alt={`${tool.name} logo`}
                        width={44}
                        height={44}
                        className="rounded-xl border border-gray-200"
                        loading="lazy"
                      />
                    )}
                    <div>
                      <h3 className="font-semibold text-gray-900 group-hover:text-brand-600 transition-colors">
                        {tool.name}
                      </h3>
                      <span className="text-xs text-gray-500">{pricingLabel[tool.pricing] || tool.pricing}</span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 line-clamp-2">{tool.tagline}</p>
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-xs text-gray-400">⭐ {tool.rating} · {tool.reviewCount.toLocaleString()} 评价</span>
                    <span className="text-xs text-brand-600 font-medium">查看详情 →</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Comparisons */}
        {comparisons.length > 0 && (
          <section className="container-content py-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">热门对比</h2>
              <Link href="/compare" className="text-brand-600 hover:underline text-sm font-medium">
                查看全部 →
              </Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {comparisons.map((comp) => (
                <Link
                  key={comp.slug}
                  href={`/compare/${comp.slug}`}
                  className="card hover:shadow-md transition-shadow group"
                >
                  <h3 className="font-medium text-gray-900 group-hover:text-brand-600 transition-colors">
                    {comp.title}
                  </h3>
                  <p className="text-sm text-gray-500 mt-1 line-clamp-2">{comp.description}</p>
                  <span className="text-xs text-brand-600 font-medium mt-2 inline-block">查看对比 →</span>
                </Link>
              ))}
            </div>
          </section>
        )}
      </main>
    </>
  )
}
