import { notFound } from 'next/navigation'
import { Metadata } from 'next'
import Link from 'next/link'
import { getAllCategories, getCategoryBySlug, getToolsByCategory } from '@/lib/data'
import { generateCategoryMetadata } from '@/lib/metadata'
import { breadcrumbSchema, articleSchema } from '@/lib/schema'
import { JsonLd } from '@/components/JsonLd'
import { Breadcrumb } from '@/components/Breadcrumb'

interface Props {
  params: Promise<{ cat: string }>
}

export async function generateStaticParams() {
  const cats = await getAllCategories()
  return cats.map((c) => ({ cat: c.slug }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { cat } = await params
  const category = await getCategoryBySlug(cat)
  if (!category) return {}
  return generateCategoryMetadata(category)
}

export default async function CategoryPage({ params }: Props) {
  const { cat } = await params
  const [category, tools] = await Promise.all([
    getCategoryBySlug(cat),
    getToolsByCategory(cat),
  ])
  if (!category) notFound()

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://ai-tools-nav.com'

  const breadcrumbs = [
    { name: '首页', url: siteUrl },
    { name: '分类', url: `${siteUrl}/category` },
    { name: category.name, url: `${siteUrl}/category/${category.slug}` },
  ]

  const pricingLabel: Record<string, string> = {
    free: '免费',
    freemium: '免费+付费',
    paid: '付费',
    enterprise: '企业版',
  }

  return (
    <>
      <JsonLd data={breadcrumbSchema(breadcrumbs)} />
      <JsonLd
        data={articleSchema({
          title: `${category.name}工具大全`,
          description: category.description,
          url: `${siteUrl}/category/${category.slug}`,
          updatedAt: new Date().toISOString(),
        })}
      />

      <main className="container-content py-8">
        <Breadcrumb items={breadcrumbs} />

        <header className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            {category.icon && <span className="text-3xl">{category.icon}</span>}
            <h1 className="text-3xl font-bold text-gray-900">{category.name}工具大全</h1>
          </div>
          <p className="text-gray-600 max-w-2xl">{category.description}</p>
          <p className="text-sm text-gray-400 mt-2">共 {tools.length} 款工具</p>
        </header>

        {tools.length === 0 ? (
          <p className="text-gray-500">该分类暂无工具，敬请期待。</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {tools.map((tool) => (
              <Link
                key={tool.slug}
                href={`/tools/${tool.slug}`}
                className="card hover:shadow-md transition-shadow group"
              >
                <div className="flex items-center gap-3 mb-3">
                  {tool.logoUrl && (
                    <img
                      src={tool.logoUrl}
                      alt={`${tool.name} logo`}
                      width={40}
                      height={40}
                      className="rounded-lg border border-gray-200"
                      loading="lazy"
                    />
                  )}
                  <div>
                    <h2 className="font-semibold text-gray-900 group-hover:text-brand-600 transition-colors">
                      {tool.name}
                    </h2>
                    <span className="text-xs text-gray-500">{pricingLabel[tool.pricing] || tool.pricing}</span>
                  </div>
                </div>
                <p className="text-sm text-gray-600 line-clamp-2">{tool.tagline}</p>
                <div className="flex items-center justify-between mt-3">
                  <span className="text-xs text-gray-400">⭐ {tool.rating}</span>
                  <span className="text-xs text-brand-600 font-medium">查看详情 →</span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
    </>
  )
}
