import { notFound } from 'next/navigation'
import { Metadata } from 'next'
import Link from 'next/link'
import { getAllComparisons, getComparisonBySlug, getToolBySlug } from '@/lib/data'
import { generateCompareMetadata } from '@/lib/metadata'
import { breadcrumbSchema, articleSchema, faqPageSchema } from '@/lib/schema'
import { JsonLd } from '@/components/JsonLd'
import { Breadcrumb } from '@/components/Breadcrumb'

interface Props {
  params: Promise<{ slug: string }>
}

export async function generateStaticParams() {
  const comparisons = await getAllComparisons()
  return comparisons.map((c) => ({ slug: c.slug }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const comparison = await getComparisonBySlug(slug)
  if (!comparison) return {}
  return generateCompareMetadata(comparison)
}

export default async function ComparePage({ params }: Props) {
  const { slug } = await params
  const comparison = await getComparisonBySlug(slug)
  if (!comparison) notFound()

  const [toolA, toolB] = await Promise.all([
    getToolBySlug(comparison.toolASlug),
    getToolBySlug(comparison.toolBSlug),
  ])
  if (!toolA || !toolB) notFound()

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://ai-tools-nav.com'

  const breadcrumbs = [
    { name: '首页', url: siteUrl },
    { name: '对比', url: `${siteUrl}/compare` },
    { name: `${toolA.name} vs ${toolB.name}`, url: `${siteUrl}/compare/${comparison.slug}` },
  ]

  const comparisonRows = [
    { label: '定价', a: toolA.pricingDetail, b: toolB.pricingDetail },
    { label: '评分', a: `⭐ ${toolA.rating}/5`, b: `⭐ ${toolB.rating}/5` },
    { label: '评价数', a: toolA.reviewCount.toLocaleString(), b: toolB.reviewCount.toLocaleString() },
    { label: '分类', a: toolA.category, b: toolB.category },
  ]

  return (
    <>
      <JsonLd data={breadcrumbSchema(breadcrumbs)} />
      <JsonLd
        data={articleSchema({
          title: comparison.title,
          description: comparison.description,
          url: `${siteUrl}/compare/${comparison.slug}`,
          updatedAt: comparison.updatedAt,
        })}
      />
      {comparison.faqs.length > 0 && <JsonLd data={faqPageSchema(comparison.faqs)} />}

      <main className="container-content py-8">
        <Breadcrumb items={breadcrumbs} />

        <header className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-gray-900">{comparison.title}</h1>
          <p className="text-gray-600 mt-2 max-w-2xl mx-auto">{comparison.description}</p>
          <p className="text-xs text-gray-400 mt-1">
            更新于 {new Date(comparison.updatedAt).toLocaleDateString('zh-CN')}
          </p>
        </header>

        {/* Hero comparison */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          {[toolA, toolB].map((tool) => (
            <div key={tool.slug} className="card text-center">
              {tool.logoUrl && (
                <img
                  src={tool.logoUrl}
                  alt={`${tool.name} logo`}
                  width={56}
                  height={56}
                  className="rounded-xl border border-gray-200 mx-auto mb-3"
                  loading="eager"
                />
              )}
              <h2 className="font-bold text-lg text-gray-900">{tool.name}</h2>
              <p className="text-sm text-gray-500 mt-1">{tool.tagline}</p>
              <a
                href={tool.website}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary mt-3 inline-block text-sm"
              >
                访问官网
              </a>
            </div>
          ))}
        </div>

        {/* Comparison table */}
        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">详细对比</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-gray-50">
                  <th className="text-left p-3 border border-gray-200 font-medium text-gray-700">对比项</th>
                  <th className="text-center p-3 border border-gray-200 font-medium text-brand-700">{toolA.name}</th>
                  <th className="text-center p-3 border border-gray-200 font-medium text-brand-700">{toolB.name}</th>
                </tr>
              </thead>
              <tbody>
                {comparisonRows.map((row) => (
                  <tr key={row.label} className="even:bg-gray-50">
                    <td className="p-3 border border-gray-200 text-gray-600">{row.label}</td>
                    <td className="p-3 border border-gray-200 text-center">{row.a}</td>
                    <td className="p-3 border border-gray-200 text-center">{row.b}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Verdict */}
        {comparison.verdict && (
          <section className="mb-8">
            <h2 className="text-xl font-semibold mb-3">总结推荐</h2>
            <div className="card bg-brand-50 border-brand-200">
              <p className="text-gray-800 leading-relaxed">{comparison.verdict}</p>
            </div>
          </section>
        )}

        {/* FAQ */}
        {comparison.faqs.length > 0 && (
          <section>
            <h2 className="text-xl font-semibold mb-3">常见问题</h2>
            <div className="space-y-4">
              {comparison.faqs.map((faq) => (
                <div key={faq.question} className="card">
                  <h3 className="font-medium text-gray-900 mb-1">{faq.question}</h3>
                  <p className="text-sm text-gray-700">{faq.answer}</p>
                </div>
              ))}
            </div>
          </section>
        )}
      </main>
    </>
  )
}
