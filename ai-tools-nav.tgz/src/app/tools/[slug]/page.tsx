import { notFound } from 'next/navigation'
import { Metadata } from 'next'
import Link from 'next/link'
import { getAllTools, getToolBySlug } from '@/lib/data'
import { generateToolMetadata } from '@/lib/metadata'
import { softwareApplicationSchema, faqPageSchema, howToSchema, breadcrumbSchema } from '@/lib/schema'
import { JsonLd } from '@/components/JsonLd'
import { Breadcrumb } from '@/components/Breadcrumb'

interface Props {
  params: Promise<{ slug: string }>
}

export async function generateStaticParams() {
  const tools = await getAllTools()
  return tools.map((t) => ({ slug: t.slug }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const tool = await getToolBySlug(slug)
  if (!tool) return {}
  return generateToolMetadata(tool)
}

export default async function ToolPage({ params }: Props) {
  const { slug } = await params
  const tool = await getToolBySlug(slug)
  if (!tool) notFound()

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://ai-tools-nav.com'

  const breadcrumbs = [
    { name: '首页', url: siteUrl },
    { name: 'AI工具', url: `${siteUrl}/tools` },
    { name: tool.name, url: `${siteUrl}/tools/${tool.slug}` },
  ]

  const pricingLabel: Record<string, string> = {
    free: '免费',
    freemium: '免费+付费',
    paid: '付费',
    enterprise: '企业版',
  }

  return (
    <>
      <JsonLd data={softwareApplicationSchema(tool)} />
      <JsonLd data={faqPageSchema(tool.faqs)} />
      <JsonLd data={howToSchema(tool)} />
      <JsonLd data={breadcrumbSchema(breadcrumbs)} />

      <main className="container-content py-8">
        <Breadcrumb items={breadcrumbs} />

        {/* Hero */}
        <div className="flex items-start gap-4 mb-8">
          {tool.logoUrl && (
            <img
              src={tool.logoUrl}
              alt={`${tool.name} logo`}
              width={64}
              height={64}
              className="rounded-xl border border-gray-200 flex-shrink-0"
              loading="eager"
            />
          )}
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{tool.name}</h1>
            <p className="text-lg text-gray-600 mt-1">{tool.tagline}</p>
            <div className="flex flex-wrap items-center gap-3 mt-3">
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-brand-100 text-brand-800">
                {pricingLabel[tool.pricing] || tool.pricing}
              </span>
              <span className="text-sm text-gray-500">
                ⭐ {tool.rating} ({tool.reviewCount.toLocaleString()} 评价)
              </span>
              <a
                href={tool.website}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary text-sm"
              >
                访问官网 →
              </a>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Description */}
            <section>
              <h2 className="text-xl font-semibold mb-3">工具介绍</h2>
              <p className="text-gray-700 leading-relaxed">{tool.description}</p>
            </section>

            {/* Features */}
            <section>
              <h2 className="text-xl font-semibold mb-3">核心功能</h2>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {tool.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-gray-700">
                    <span className="text-green-500 flex-shrink-0">✓</span>
                    {f}
                  </li>
                ))}
              </ul>
            </section>

            {/* Pros / Cons */}
            <section>
              <h2 className="text-xl font-semibold mb-3">优缺点分析</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="card">
                  <h3 className="font-medium text-green-700 mb-2">✅ 优点</h3>
                  <ul className="space-y-1">
                    {tool.pros.map((p) => (
                      <li key={p} className="text-sm text-gray-700">{p}</li>
                    ))}
                  </ul>
                </div>
                <div className="card">
                  <h3 className="font-medium text-red-700 mb-2">❌ 缺点</h3>
                  <ul className="space-y-1">
                    {tool.cons.map((c) => (
                      <li key={c} className="text-sm text-gray-700">{c}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </section>

            {/* How To */}
            <section>
              <h2 className="text-xl font-semibold mb-3">如何使用 {tool.name}</h2>
              <ol className="space-y-4">
                {tool.howToSteps.map((step, i) => (
                  <li key={step.name} className="flex gap-4">
                    <span className="flex-shrink-0 w-7 h-7 rounded-full bg-brand-600 text-white text-sm font-bold flex items-center justify-center">
                      {i + 1}
                    </span>
                    <div>
                      <p className="font-medium text-gray-900">{step.name}</p>
                      <p className="text-sm text-gray-600 mt-0.5">{step.text}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </section>

            {/* FAQ */}
            <section>
              <h2 className="text-xl font-semibold mb-3">常见问题</h2>
              <div className="space-y-4">
                {tool.faqs.map((faq) => (
                  <div key={faq.question} className="card">
                    <h3 className="font-medium text-gray-900 mb-1">{faq.question}</h3>
                    <p className="text-sm text-gray-700">{faq.answer}</p>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <aside className="space-y-6">
            {/* Quick info */}
            <div className="card">
              <h2 className="font-semibold mb-3">基本信息</h2>
              <dl className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <dt className="text-gray-500">定价</dt>
                  <dd className="font-medium">{tool.pricingDetail}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-gray-500">评分</dt>
                  <dd className="font-medium">⭐ {tool.rating}/5</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-gray-500">分类</dt>
                  <dd>
                    <Link href={`/category/${tool.category}`} className="text-brand-600 hover:underline">
                      {tool.category}
                    </Link>
                  </dd>
                </div>
              </dl>
              <a
                href={tool.website}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary w-full text-center mt-4 block"
              >
                免费试用
              </a>
            </div>

            {/* Tags */}
            <div className="card">
              <h2 className="font-semibold mb-3">标签</h2>
              <div className="flex flex-wrap gap-2">
                {tool.tags.map((tag) => (
                  <span key={tag} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-md">
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Use cases */}
            <div className="card">
              <h2 className="font-semibold mb-3">适用场景</h2>
              <ul className="space-y-1">
                {tool.useCases.map((uc) => (
                  <li key={uc} className="text-sm text-gray-700 flex items-center gap-2">
                    <span className="text-brand-500">→</span>
                    {uc}
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </div>
      </main>
    </>
  )
}
