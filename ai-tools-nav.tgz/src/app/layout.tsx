import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap', // font-display: swap prevents FOIT, reduces CLS
  preload: true,
})

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://ai-tools-nav.com'
const siteName = process.env.NEXT_PUBLIC_SITE_NAME || 'AI工具导航'

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: `${siteName} - 发现最好的AI工具`,
    template: `%s | ${siteName}`,
  },
  description: '精选AI工具导航与测评，帮助你找到最适合的人工智能工具，提升工作效率。',
  keywords: ['AI工具', '人工智能', 'AI导航', 'AI测评', 'ChatGPT', 'AI助手'],
  authors: [{ name: siteName }],
  creator: siteName,
  openGraph: {
    type: 'website',
    locale: 'zh_CN',
    url: siteUrl,
    siteName,
    title: `${siteName} - 发现最好的AI工具`,
    description: '精选AI工具导航与测评，帮助你找到最适合的人工智能工具。',
  },
  twitter: {
    card: 'summary_large_image',
    title: `${siteName} - 发现最好的AI工具`,
    description: '精选AI工具导航与测评，帮助你找到最适合的人工智能工具。',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  alternates: {
    canonical: siteUrl,
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="zh-CN" className={inter.variable}>
      <head>
        {/* Preconnect to critical origins for TTFB improvement */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body>
        <a href="#main-content" className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-brand-500 focus:text-white focus:rounded">
          跳转到主内容
        </a>
        <main id="main-content">
          {children}
        </main>
      </body>
    </html>
  )
}
