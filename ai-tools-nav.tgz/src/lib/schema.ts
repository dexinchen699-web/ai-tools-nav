import { AITool, BreadcrumbItem, FAQ } from './types'

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://ai-tools-nav.com'
const siteName = process.env.NEXT_PUBLIC_SITE_NAME || 'AI工具导航'

// SoftwareApplication schema for tool pages
export function softwareApplicationSchema(tool: AITool) {
  return {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: tool.name,
    description: tool.description,
    url: tool.website,
    applicationCategory: 'WebApplication',
    operatingSystem: 'Web',
    offers: {
      '@type': 'Offer',
      price: tool.pricing === 'free' ? '0' : undefined,
      priceCurrency: 'USD',
      description: tool.pricingDetail,
    },
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: tool.rating,
      reviewCount: tool.reviewCount,
      bestRating: 5,
      worstRating: 1,
    },
    ...(tool.imageUrl && { image: `${siteUrl}${tool.imageUrl}` }),
  }
}

// FAQPage schema
export function faqPageSchema(faqs: FAQ[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map((faq) => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer,
      },
    })),
  }
}

// HowTo schema
export function howToSchema(tool: AITool) {
  return {
    '@context': 'https://schema.org',
    '@type': 'HowTo',
    name: `如何使用${tool.name}`,
    description: `${tool.name}使用教程，手把手教你快速上手`,
    step: tool.howToSteps.map((step, i) => ({
      '@type': 'HowToStep',
      position: i + 1,
      name: step.name,
      text: step.text,
      ...(step.imageUrl && { image: step.imageUrl }),
    })),
  }
}

// BreadcrumbList schema
export function breadcrumbSchema(items: BreadcrumbItem[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      item: item.url,
    })),
  }
}

// Article schema for comparison pages
export function articleSchema({
  title,
  description,
  url,
  updatedAt,
}: {
  title: string
  description: string
  url: string
  updatedAt: string
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: title,
    description,
    url,
    dateModified: updatedAt,
    publisher: {
      '@type': 'Organization',
      name: siteName,
      url: siteUrl,
    },
  }
}
