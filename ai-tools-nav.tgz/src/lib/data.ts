import { AITool, Category, Comparison } from './types'

// Seed data — replace with Supabase queries in Phase 2
export const CATEGORIES: Category[] = [
  { id: '1', slug: 'writing', name: 'AI写作', description: 'AI驱动的写作、文案和内容创作工具', iconName: 'PencilIcon', icon: '✍️', toolCount: 12 },
  { id: '2', slug: 'image', name: 'AI绘图', description: 'AI图像生成、编辑和设计工具', iconName: 'PhotoIcon', icon: '🎨', toolCount: 8 },
  { id: '3', slug: 'coding', name: 'AI编程', description: 'AI代码生成、补全和调试工具', iconName: 'CodeBracketIcon', icon: '💻', toolCount: 10 },
  { id: '4', slug: 'chat', name: 'AI对话', description: 'AI聊天机器人和智能助手', iconName: 'ChatBubbleIcon', icon: '💬', toolCount: 15 },
  { id: '5', slug: 'video', name: 'AI视频', description: 'AI视频生成、编辑和字幕工具', iconName: 'VideoCameraIcon', icon: '🎬', toolCount: 6 },
  { id: '6', slug: 'seo', name: 'AI SEO', description: 'AI驱动的SEO分析和内容优化工具', iconName: 'MagnifyingGlassIcon', icon: '🔍', toolCount: 5 },
]

export const TOOLS: AITool[] = [
  {
    id: '1',
    slug: 'chatgpt',
    name: 'ChatGPT',
    tagline: 'OpenAI出品的最强AI对话助手',
    description: 'ChatGPT是由OpenAI开发的大型语言模型，能够进行自然对话、写作、编程、分析等多种任务。支持GPT-4o多模态能力，可处理文字、图片和文件。',
    category: 'chat',
    tags: ['对话', '写作', '编程', 'GPT-4'],
    website: 'https://chat.openai.com',
    pricing: 'freemium',
    pricingDetail: '免费版 / Plus $20/月 / Team $25/月',
    rating: 4.8,
    reviewCount: 1240,
    features: ['GPT-4o多模态', '插件生态', 'DALL-E图像生成', '代码解释器', '自定义GPTs'],
    pros: ['功能最全面', '生态最丰富', '中文支持好'],
    cons: ['免费版有限制', '高峰期较慢', '需要科学上网'],
    useCases: ['内容创作', '代码调试', '数据分析', '学习辅助'],
    faqs: [
      { question: 'ChatGPT免费版和Plus版有什么区别？', answer: '免费版使用GPT-3.5，Plus版($20/月)可使用GPT-4o，速度更快，功能更多，包括图像生成和高级数据分析。' },
      { question: 'ChatGPT支持中文吗？', answer: '完全支持中文，可以用中文提问和获得中文回答，中文理解能力非常强。' },
    ],
    howToSteps: [
      { name: '注册账号', text: '访问chat.openai.com，使用邮箱或Google账号注册' },
      { name: '开始对话', text: '在输入框输入你的问题或任务，按Enter发送' },
      { name: '优化提示词', text: '使用清晰、具体的提示词获得更好的回答' },
    ],
    imageUrl: '/images/tools/chatgpt.webp',
    logoUrl: '/images/logos/chatgpt.webp',
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2026-04-01T00:00:00Z',
    isFeatured: true,
  },
  {
    id: '2',
    slug: 'claude',
    name: 'Claude',
    tagline: 'Anthropic出品的安全可靠AI助手',
    description: 'Claude是Anthropic开发的AI助手，以安全性和长文本处理能力著称。Claude 3.5 Sonnet在编程、分析和写作方面表现出色，支持200K token超长上下文。',
    category: 'chat',
    tags: ['对话', '写作', '编程', '长文本'],
    website: 'https://claude.ai',
    pricing: 'freemium',
    pricingDetail: '免费版 / Pro $20/月',
    rating: 4.7,
    reviewCount: 890,
    features: ['200K超长上下文', '代码生成', '文档分析', 'Artifacts功能', '安全对齐'],
    pros: ['长文本处理最强', '代码质量高', '回答更安全'],
    cons: ['图像生成能力弱', '插件生态少', '需要科学上网'],
    useCases: ['长文档分析', '代码开发', '学术写作', '数据处理'],
    faqs: [
      { question: 'Claude和ChatGPT哪个更好？', answer: 'Claude在长文本处理和代码生成方面更强，ChatGPT在生态和多模态方面更丰富，各有优势。' },
      { question: 'Claude支持中文吗？', answer: '支持中文，但中文能力略弱于英文，适合处理中英混合内容。' },
    ],
    howToSteps: [
      { name: '访问官网', text: '打开claude.ai，使用邮箱注册账号' },
      { name: '选择模型', text: '免费版使用Claude 3 Haiku，Pro版可使用Claude 3.5 Sonnet' },
      { name: '上传文件', text: '可直接上传PDF、代码文件进行分析' },
    ],
    imageUrl: '/images/tools/claude.webp',
    logoUrl: '/images/logos/claude.webp',
    createdAt: '2024-01-15T00:00:00Z',
    updatedAt: '2026-04-01T00:00:00Z',
    isFeatured: true,
  },
  {
    id: '3',
    slug: 'midjourney',
    name: 'Midjourney',
    tagline: '最受欢迎的AI图像生成工具',
    description: 'Midjourney是目前最流行的AI图像生成工具，以其艺术性和高质量图像著称。通过Discord或网页版输入文字描述即可生成精美图像。',
    category: 'image',
    tags: ['图像生成', '艺术', '设计', 'Discord'],
    website: 'https://midjourney.com',
    pricing: 'paid',
    pricingDetail: 'Basic $10/月 / Standard $30/月 / Pro $60/月',
    rating: 4.6,
    reviewCount: 2100,
    features: ['高质量图像生成', '多种艺术风格', '图像变体', '放大功能', 'V6最新模型'],
    pros: ['图像质量最高', '艺术风格丰富', '社区活跃'],
    cons: ['无免费版', '需要Discord', '学习曲线较陡'],
    useCases: ['艺术创作', '商业设计', '概念图', '社交媒体内容'],
    faqs: [
      { question: 'Midjourney有免费试用吗？', answer: '目前Midjourney已取消免费试用，最低套餐为$10/月，包含约200张图片生成额度。' },
      { question: '如何使用Midjourney？', answer: '加入Midjourney Discord服务器，在bot频道输入/imagine命令加上描述词即可生成图像。' },
    ],
    howToSteps: [
      { name: '加入Discord', text: '访问midjourney.com，点击Join the Beta加入Discord服务器' },
      { name: '订阅套餐', text: '输入/subscribe命令选择适合的付费套餐' },
      { name: '生成图像', text: '在bot频道输入/imagine [你的描述]开始生成' },
    ],
    imageUrl: '/images/tools/midjourney.webp',
    logoUrl: '/images/logos/midjourney.webp',
    createdAt: '2024-02-01T00:00:00Z',
    updatedAt: '2026-03-15T00:00:00Z',
    isFeatured: true,
  },
]

export const COMPARISONS: Comparison[] = [
  {
    id: '1',
    slug: 'chatgpt-vs-claude',
    toolASlug: 'chatgpt',
    toolBSlug: 'claude',
    title: 'ChatGPT vs Claude：2026年深度对比',
    description: '全面对比ChatGPT和Claude在功能、价格、中文支持等方面的差异，帮你选择最适合的AI助手。',
    verdict: '如果你需要最全面的功能和最丰富的插件生态，选ChatGPT Plus；如果你主要处理长文档、代码开发或需要更安全的回答，Claude Pro更适合你。两者都提供$20/月的Pro套餐，可以根据主要使用场景来决定。',
    faqs: [
      { question: 'ChatGPT和Claude哪个中文更好？', answer: 'ChatGPT的中文理解和生成能力略强，更适合纯中文内容创作；Claude在中英混合场景下表现也很好。' },
      { question: '两者都需要科学上网吗？', answer: '是的，ChatGPT和Claude目前都需要科学上网才能访问，国内用户需要使用VPN。' },
    ],
    updatedAt: '2026-04-01T00:00:00Z',
  },
]

// Data access functions — swap these for Supabase queries in Phase 2
export async function getAllTools(): Promise<AITool[]> {
  return TOOLS
}

export async function getToolBySlug(slug: string): Promise<AITool | null> {
  return TOOLS.find((t) => t.slug === slug) ?? null
}

export async function getAllCategories(): Promise<Category[]> {
  return CATEGORIES
}

export async function getCategoryBySlug(slug: string): Promise<Category | null> {
  return CATEGORIES.find((c) => c.slug === slug) ?? null
}

export async function getToolsByCategory(categorySlug: string): Promise<AITool[]> {
  return TOOLS.filter((t) => t.category === categorySlug)
}

export async function getAllComparisons(): Promise<Comparison[]> {
  return COMPARISONS
}

export async function getComparisonBySlug(slug: string): Promise<Comparison | null> {
  return COMPARISONS.find((c) => c.slug === slug) ?? null
}

export async function getFeaturedTools(): Promise<AITool[]> {
  return TOOLS.filter((t) => t.isFeatured)
}
