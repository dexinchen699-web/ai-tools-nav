import { Metadata } from 'next'
import { AITool, Category, Comparison } from './types'

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://ai-tools-nav.com'
const siteName = process.env.NEXT_PUBLIC_SITE_NAME || 'AI工具导航'

// Tool detail page metadata
export function generateToolMetadata(tool: AITool): Metadata {
  const title = `${tool.name}评测 - ${tool.tagline}`
  const description = `${tool.name}详细评测：功能介绍、价格对比、使用教程。${tool.description.slice(0, 80)}...`

  return {
    title,
    description,
    keywords: [tool.name, ...tool.tags, 'AI工具', '评测', '使用教程'],
    openGraph: {
      title,
      description,
      url: `${siteUrl}/tools/${tool.slug}`,
      type: 'article',
      ...(tool.imageUrl && { images: [{ url: tool.imageUrl, alt: tool.name }] }),
    },
    twitter: { card: 'summary_large_image', title, description },
    alternates: { canonical: `${siteUrl}/tools/${tool.slug}` },
  }
}

// Category page metadata
export function generateCategoryMetadata(category: Category): Metadata {
  const title = `${category.name}工具大全 - 精选${category.toolCount || ''}款AI工具`
  const description = `${category.description}。精选最好用的${category.name}工具，附详细评测和使用教程。`

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      url: `${siteUrl}/category/${category.slug}`,
    },
    alternates: { canonical: `${siteUrl}/category/${category.slug}` },
  }
}

// Compare page metadata
export function generateCompareMetadata(comparison: Comparison): Metadata {
  const title = comparison.title
  const description = comparison.description

  return {
    title,
    description,
    openGraph: { title, description, url: `${siteUrl}/compare/${comparison.slug}` },
    alternates: { canonical: `${siteUrl}/compare/${comparison.slug}` },
  }
}
