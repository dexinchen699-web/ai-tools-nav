// Injects JSON-LD structured data as a <script> tag
// Usage: <JsonLd data={softwareApplicationSchema(tool)} />
export function JsonLd({ data }: { data: Record<string, unknown> | Record<string, unknown>[] }) {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  )
}
